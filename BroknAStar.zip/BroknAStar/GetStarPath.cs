using Pathfinding;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{

	[ActionCategory("Brokn")]
	public class GetStarPath : FsmStateAction
	{
		public FsmOwnerDefault gameObject;
		public FsmGameObject TargetGameObject;
		public FsmFloat UpdateCycleSpeed;
		public FsmFloat UpdateDistance;
		public FsmVector3 TargetPosition;
		public FsmVector2 TargetPosition2D;
		private FSMPathHolder PH;
		
		
		public FsmVector3 Returned;
		public FsmVector2 Returned2d;
	
		float timer = 5;

        public override void OnEnter()
        {
			PH = Fsm.GetOwnerDefaultTarget(gameObject).GetComponent<FSMPathHolder>();

		}
        public override void OnUpdate()
		{
			timer += Time.deltaTime;
			if (timer > UpdateCycleSpeed.Value)
            {
				if(TargetGameObject.Value != null)
                {
					if (TargetPosition.Value != null)
                    {
						Vector3 Temp = TargetGameObject.Value.transform.position + TargetPosition.Value;
						GetV3Target(Temp);
                    }
                    else
					{
						if (TargetPosition2D.Value != null)
						{
							Vector2 Temp = (Vector2)TargetGameObject.Value.transform.position + TargetPosition2D.Value;
							GetV2Target(Temp);
						}
						else if (TargetPosition2D.Value != null)
						{
							Vector2 Temp = (Vector2)TargetGameObject.Value.transform.position + TargetPosition2D.Value;
							GetV2Target(Temp);
						}
						else
						{
							GetGOTarget(TargetGameObject.Value);
						}
						
                    }
					 if(TargetPosition2D.Value != null )
					{
						Vector2 Temp = (Vector2)TargetGameObject.Value.transform.position + TargetPosition2D.Value;
						GetV2Target(Temp);
					}
					else
					{
						GetGOTarget(TargetGameObject.Value);

					}
				}
				
				else if (TargetPosition.Value != null)
                {
					 
					GetV3Target(TargetPosition.Value);
				}
				else if (TargetPosition2D.Value != null)
				{

					GetV2Target(TargetPosition2D.Value);
				}
				timer = 0;
            }
			if (PH.path == null) { return; }
			Returned.Value =  PH.path.vectorPath[PH.CurrentWayPoint]-Fsm.GetOwnerDefaultTarget(gameObject).transform.position;
			Returned2d.Value = PH.path.vectorPath[PH.CurrentWayPoint] - Fsm.GetOwnerDefaultTarget(gameObject).transform.position;

			float distance = Vector3.Distance(Fsm.GetOwnerDefaultTarget(gameObject).transform.position, PH.path.vectorPath[PH.CurrentWayPoint]);
			if (distance < UpdateDistance.Value)
			{
				PH.CurrentWayPoint++;
			}
		}
		void GetGOTarget(GameObject G)
        {
			PH.UpDatePath(Fsm.GetOwnerDefaultTarget(gameObject), G);
		}
		void GetV3Target(Vector3 POS)
        {
			PH.UpDatePath(Fsm.GetOwnerDefaultTarget(gameObject), POS);
		}
		void GetV2Target(Vector2 POS)
        {
			PH.UpDatePath(Fsm.GetOwnerDefaultTarget(gameObject), POS);
		}
	

    }

}
