using Pathfinding;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FSMPathHolder : MonoBehaviour
{
	public Path path;
	public int CurrentWayPoint = 0;
	private Seeker Seek;
    public void Start()
    {
		Seek = GetComponent<Seeker>();
    }

    public void UpDatePath(GameObject Owner,GameObject Target)
	{
		
		if (Target == null) { return; }
		if (Seek.IsDone())
		{
		
			Seek.StartPath(Owner.transform.position, Target.transform.position, OnPathComplete);
			
		}
	}
	public void UpDatePath(GameObject Owner, Vector3 Target)
	{

		if (Target == null) { return; }
		if (Seek.IsDone())
		{

			Seek.StartPath(Owner.transform.position, Target, OnPathComplete);

		}
	}
	public void UpDatePath(GameObject Owner, Vector2 Target)
	{

		if (Target == null) { return; }
		if (Seek.IsDone())
		{

			Seek.StartPath(Owner.transform.position, Target, OnPathComplete);

		}
	}
	public void OnPathComplete(Path p)
	{
		
		if (!p.error)
		{
			
			path = p;
			CurrentWayPoint = 0;
		}
     
	}
}
